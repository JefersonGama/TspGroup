// utils/charts-config.js

/**
 * Configuração padrão para gráficos de barras
 * @returns {Object}
 */
export function getConfigGraficoBarras() {
    return {
        type: 'bar',
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Gráfico Padrão'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    };
}

/**
 * Configuração padrão para gráficos de pizza/donut
 * @returns {Object}
 */
export function getConfigGraficoPizza() {
    return {
        type: 'doughnut',
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Gráfico Padrão'
                }
            }
        }
    };
}

/**
 * Paleta de cores padrão do sistema
 */
export const coresSistema = {
    primaria: '#BADA52', // Verde
    secundaria: '#64C4DF', // Azul
    destaque: '#FFCE56',  // Amarelo
    alerta: '#FF6384',    // Vermelho
    sucesso: '#4BC0C0'    // Verde-água
};