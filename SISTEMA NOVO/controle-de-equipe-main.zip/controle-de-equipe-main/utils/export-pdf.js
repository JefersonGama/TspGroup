// utils/export-pdf.js
// Esta função assume que jsPDF foi carregado no HTML
// <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>

/**
 * Exporta uma tabela HTML para PDF
 * @param {string} tableId - ID do elemento <table> no HTML
 * @param {string} titulo - Título do relatório no PDF
 */
export async function exportarTabelaParaPDF(tableId, titulo = 'Relatório') {
    if (typeof window.jsPDF === 'undefined') {
        console.error('jsPDF não está carregado.');
        alert('Erro: Biblioteca para PDF não está disponível.');
        return;
    }

    const { jsPDF } = window;
    const pdf = new jsPDF();

    const table = document.getElementById(tableId);
    if (!table) {
        console.error('Tabela com ID', tableId, 'não encontrada.');
        return;
    }

    pdf.text(titulo, 14, 15);

    // Usando a funcionalidade html de jsPDF (requer plugin html, carregado com o .umd)
    pdf.html(table, {
        callback: function (doc) {
            doc.save(titulo + '.pdf');
        },
        x: 10,
        y: 20,
        html2canvas: { scale: 0.8 },
        jsPDF: doc,
    });

    // Outra opção mais robusta é usar autoTable
    // pdf.autoTable({ html: table });
    // pdf.save(titulo + '.pdf');
}