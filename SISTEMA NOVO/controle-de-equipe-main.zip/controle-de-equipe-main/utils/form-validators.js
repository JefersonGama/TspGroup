// utils/form-validators.js

/**
 * Valida se um e-mail é válido
 * @param {string} email
 * @returns {boolean}
 */
export function validarEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

/**
 * Valida se uma senha é forte o suficiente
 * Critérios: pelo menos 8 caracteres, uma letra maiúscula, uma minúscula e um número
 * @param {string} senha
 * @returns {boolean}
 */
export function validarSenha(senha) {
    const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d@$!%*?&]{8,}$/;
    return re.test(senha);
}

/**
 * Valida se um campo de texto não está vazio ou é só espaços
 * @param {string} texto
 * @returns {boolean}
 */
export function validarCampoTexto(texto) {
    return texto && texto.trim().length > 0;
}

/**
 * Valida se um número é positivo
 * @param {number} numero
 * @returns {boolean}
 */
export function validarNumeroPositivo(numero) {
    return typeof numero === 'number' && numero > 0;
}

/**
 * Valida um objeto de dados de formulário com base em regras
 * @param {Object} dados - Dados do formulário
 * @param {Object} regras - Objeto com nome do campo e função de validação
 * @returns {{valido: boolean, erros: Object}}
 */
export function validarFormulario(dados, regras) {
    const erros = {};
    let valido = true;

    for (const [campo, regra] of Object.entries(regras)) {
        const valor = dados[campo];
        if (!regra(valor)) {
            erros[campo] = `Campo '${campo}' é inválido.`;
            valido = false;
        }
    }

    return { valido, erros };
}