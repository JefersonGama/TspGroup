// utils/date-helpers.js

/**
 * Formata uma data no padrão brasileiro (DD/MM/AAAA)
 * @param {Date} date - Objeto Date do JavaScript
 * @returns {string} - Data formatada
 */
export function formatarDataBr(date) {
    if (!(date instanceof Date)) {
        console.error("O argumento deve ser um objeto Date.");
        return '';
    }
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Janeiro é 0!
    const year = date.getFullYear();
    return `${day}/${month}/${year}`;
}

/**
 * Converte uma string de data no formato DD/MM/AAAA para um objeto Date
 * @param {string} dateString - Data no formato DD/MM/AAAA
 * @returns {Date | null} - Objeto Date ou null se inválido
 */
export function parseDataBr(dateString) {
    const [day, month, year] = dateString.split('/');
    if (!day || !month || !year) {
        return null;
    }
    // Mês é 0-indexado no JS, por isso subtraímos 1
    const date = new Date(year, month - 1, day);
    // Validação simples: se a data criada não corresponde aos valores originais, é inválida
    if (date.getDate() !== parseInt(day) || date.getMonth() !== month - 1 || date.getFullYear() !== parseInt(year)) {
        return null;
    }
    return date;
}

/**
 * Retorna a data de início e fim da semana atual
 * @returns {{inicio: Date, fim: Date}}
 */
export function getSemanaAtual() {
    const today = new Date();
    const firstDayOfWeek = new Date(today);
    const lastDayOfWeek = new Date(today);

    const dayOfWeek = today.getDay(); // 0 (Domingo) a 6 (Sábado)
    const diffToMonday = today.getDate() - dayOfWeek + (dayOfWeek === 0 ? -6 : 1); // Ajusta para segunda-feira

    firstDayOfWeek.setDate(diffToMonday);
    firstDayOfWeek.setHours(0, 0, 0, 0);

    lastDayOfWeek.setDate(diffToMonday + 6);
    lastDayOfWeek.setHours(23, 59, 59, 999);

    return { inicio: firstDayOfWeek, fim: lastDayOfWeek };
}

/**
 * Retorna a data de início e fim do mês atual
 * @returns {{inicio: Date, fim: Date}}
 */
export function getMesAtual() {
    const today = new Date();
    const inicio = new Date(today.getFullYear(), today.getMonth(), 1);
    const fim = new Date(today.getFullYear(), today.getMonth() + 1, 0);
    fim.setHours(23, 59, 59, 999);
    return { inicio, fim };
}