-- supabase/database/schema.sql

-- Tabela de Usuários (Administradores e Técnicos)
CREATE TABLE usuarios (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    email TEXT UNIQUE NOT NULL,
    nome TEXT NOT NULL,
    tipo_usuario TEXT CHECK (tipo_usuario IN ('admin', 'tecnico')) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de Técnicos (ligada à tabela de usuários)
CREATE TABLE tecnicos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    usuario_id UUID REFERENCES usuarios(id) ON DELETE CASCADE,
    nome_completo TEXT NOT NULL,
    funcao TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de Avisos
CREATE TABLE avisos (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    titulo TEXT NOT NULL,
    descricao TEXT,
    data_aviso DATE NOT NULL,
    status TEXT CHECK (status IN ('ativo', 'resolvido', 'pendente')) DEFAULT 'ativo',
    tecnico_responsavel_id UUID REFERENCES tecnicos(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Tabela de Produção Diária por Técnico
CREATE TABLE producao (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    tecnico_id UUID REFERENCES tecnicos(id) ON DELETE CASCADE,
    data_producao DATE NOT NULL,
    quantidade INTEGER NOT NULL,
    descricao TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    UNIQUE(tecnico_id, data_producao) -- Impede duplicatas para o mesmo técnico no mesmo dia
);