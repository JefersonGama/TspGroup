-- supabase/database/policies.sql

-- Habilitar RLS nas tabelas
ALTER TABLE avisos ENABLE ROW LEVEL SECURITY;
ALTER TABLE tecnicos ENABLE ROW LEVEL SECURITY;
-- ... outras tabelas

-- Política para que usuários técnicos só vejam avisos atribuídos a eles
CREATE POLICY "Técnicos podem ver apenas seus avisos atribuídos" ON avisos
FOR SELECT TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM usuarios WHERE email = auth.email() AND tipo_usuario = 'tecnico'
    )
    AND tecnico_responsavel_id = (
        SELECT t.id FROM tecnicos t JOIN usuarios u ON t.usuario_id = u.id WHERE u.email = auth.email()
    )
);

-- Política para que administradores vejam todos os avisos
CREATE POLICY "Admins podem ver todos os avisos" ON avisos
FOR SELECT TO authenticated
USING (
    EXISTS (
        SELECT 1 FROM usuarios WHERE email = auth.email() AND tipo_usuario = 'admin'
    )
);
-- ... outras políticas