-- supabase/database/seed-data.sql

-- Inserir um administrador padrão (CUIDADO: não usar em produção com senha fixa)
-- Supondo que você tenha um usuário admin previamente criado no Auth com email 'admin@tsp.com'
-- e que você saiba o ID dele (ex: 'auth_user_id_admin').
-- INSERT INTO usuarios (id, email, nome, tipo_usuario) VALUES
-- ('auth_user_id_admin', 'admin@tsp.com', 'Administrador Padrão', 'admin');

-- Inserir alguns técnicos de exemplo (assumindo que os usuários já existam no Auth e na tabela 'usuarios')
-- INSERT INTO tecnicos (usuario_id, nome_completo, funcao) VALUES
-- ('auth_user_id_tec1', 'Técnico João Silva', 'Mecânico'),
-- ('auth_user_id_tec2', 'Técnica Maria Oliveira', 'Eletricista');

-- Inserir alguns avisos de exemplo
-- INSERT INTO avisos (titulo, descricao, data_aviso, status, tecnico_responsavel_id) VALUES
-- ('Manutenção Preventiva Linha A', 'Verificar correias e lubrificação.', '2025-10-01', 'ativo', 'id_do_tecnico_joao'),
-- ('Falha na Prensa Hidráulica', 'Pressão baixa, verificar válvulas.', '2025-10-02', 'pendente', 'id_do_tecnico_maria');

-- Inserir dados de produção de exemplo
-- INSERT INTO producao (tecnico_id, data_producao, quantidade, descricao) VALUES
-- ('id_do_tecnico_joao', '2025-10-01', 120, 'Produção da peça X'),
-- ('id_do_tecnico_maria', '2025-10-01', 95, 'Produção da peça Y');