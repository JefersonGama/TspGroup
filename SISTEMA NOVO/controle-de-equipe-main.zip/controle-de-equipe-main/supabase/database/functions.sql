-- supabase/database/functions.sql

-- Exemplo: Função para atualizar automaticamente a coluna 'updated_at'
-- Pode ser usada com um trigger
CREATE OR REPLACE FUNCTION atualizar_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Exemplo: Função para verificar se um usuário é admin antes de permitir uma ação
-- Pode ser usada em RLS ou em stored procedures
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
    RETURN (SELECT tipo_usuario = 'admin' FROM usuarios WHERE email = auth.email());
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;