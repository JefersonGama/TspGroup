-- supabase/database/triggers.sql

-- Exemplo: Trigger para atualizar 'updated_at' antes de qualquer UPDATE em uma tabela
-- (Precisa ser aplicado a cada tabela desejada)
-- Exemplo para a tabela 'avisos':
-- CREATE TRIGGER atualizar_avisos_updated_at
--     BEFORE UPDATE ON avisos
--     FOR EACH ROW
--     EXECUTE FUNCTION atualizar_updated_at();

-- Exemplo para a tabela 'tecnicos':
-- CREATE TRIGGER atualizar_tecnicos_updated_at
--     BEFORE UPDATE ON tecnicos
--     FOR EACH ROW
--     EXECUTE FUNCTION atualizar_updated_at();