// supabase/supabase-config.js
// OU poderia ser colocado em assets/js/supabase-config.js
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const SUPABASE_URL = 'https://mnpheqtvhjyuoxfylvez.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1ucGhlcXR2aGp5dW94ZnlsdmV6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTkwODU2NDQsImV4cCI6MjA3NDY2MTY0NH0.a_2y0vALsHqqPOX3_mxAjv9TNOwBHKnrT6yx8lv-Nfc';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);