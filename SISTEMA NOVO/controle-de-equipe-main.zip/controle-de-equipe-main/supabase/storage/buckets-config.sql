-- supabase/storage/buckets-config.sql

-- Criar bucket para avatares de usuários
INSERT INTO storage.buckets (id, name, public)
VALUES ('avatars', 'avatars', true);

-- Outros buckets podem ser adicionados aqui
-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('uploads', 'uploads', false);