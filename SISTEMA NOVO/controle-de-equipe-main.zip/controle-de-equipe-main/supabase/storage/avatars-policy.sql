-- supabase/storage/avatars-policy.sql

-- Permitir que usuários autenticados leiam do bucket 'avatars'
CREATE POLICY "Usuários autenticados podem ler avatares" ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'avatars');

-- Permitir que usuários autenticados insiram (façam upload) no bucket 'avatars', com limite de nome e tipo
CREATE POLICY "Usuários autenticados podem fazer upload de avatares" ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'avatars'
    AND (storage.filename(new.name) ~ '^avatar_[a-f0-9-]{36}\.(jpg|jpeg|png|gif|webp)$') -- Exemplo de padrão de nome
    AND new.owner = auth.uid() -- O proprietário do objeto é o usuário logado
  );

-- Permitir que usuários autenticados atualizem (troquem) seu próprio avatar
CREATE POLICY "Usuários autenticados podem atualizar seus próprios avatares" ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'avatars' AND owner = auth.uid())
  WITH CHECK (bucket_id = 'avatars' AND owner = auth.uid());

-- Permitir que usuários autenticados deletem seu próprio avatar
CREATE POLICY "Usuários autenticados podem deletar seus próprios avatares" ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND owner = auth.uid());