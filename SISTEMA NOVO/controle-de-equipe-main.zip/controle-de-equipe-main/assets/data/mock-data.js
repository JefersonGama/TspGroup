// Mock data
export const AVISOS = [
  { id:1, titulo: 'Teste', mensagem: 'Aviso de teste', data:'2025-10-05' }
];
