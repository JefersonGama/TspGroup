import { supabase } from "../../supabase/supabase-config.js";

// ============================
// FUNÇÃO DE IMPRESSÃO
// ============================
function imprimirSecao(secaoId) {
  const secao = document.getElementById(secaoId);
  if (!secao) return;

  const clone = secao.cloneNode(true);
  clone.querySelectorAll('.action-buttons, .btn-primary, .btn-imprimir, .page-actions').forEach(el => el.remove());

  const printWindow = window.open('', '_blank');
  printWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>Relatório</title>
      <style>
        body { font-family: 'Segoe UI', sans-serif; padding: 20px; color: #333; background: white; }
        h2 { color: #2c3e50; border-bottom: 2px solid #BADA52; padding-bottom: 8px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 10px; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #f4f6f8; font-weight: 600; }
        tr:nth-child(even) { background-color: #fafafa; }
      </style>
    </head>
    <body>
      ${clone.outerHTML}
    </body>
    </html>
  `);
  printWindow.document.close();
  printWindow.focus();
  printWindow.print();
  printWindow.close();
}

// ============================
// FUNÇÃO PARA CRIAR BOTÃO DE IMPRESSÃO
// ============================
function criarBotaoImprimir(secaoId) {
  const btn = document.createElement('button');
  btn.className = 'btn-imprimir';
  btn.innerHTML = '🖨️ Imprimir Relatório';
  btn.type = 'button';
  btn.addEventListener('click', () => imprimirSecao(secaoId));
  return btn;
}

// ============================
// INSERIR BOTÕES DE IMPRESSÃO NA PÁGINA
// ============================
function inserirBotoesImpressao() {
  const containerProducao = document.querySelector('#producao-section .page-actions > div:last-child');
  if (containerProducao && !containerProducao.querySelector('.btn-imprimir')) {
    containerProducao.appendChild(criarBotaoImprimir('producao-section'));
  }

  const containerRetornos = document.querySelector('#retornos-section .page-actions > div:last-child');
  if (containerRetornos && !containerRetornos.querySelector('.btn-imprimir')) {
    containerRetornos.appendChild(criarBotaoImprimir('retornos-section'));
  }
}

// ============================
// DOM CONTENT LOADED
// ============================
document.addEventListener("DOMContentLoaded", async () => {
  // ============================
  // ELEMENTOS DOM
  // ============================
  const btnAdicionarProducao = document.getElementById("btnAdicionarProducao");
  const btnAdicionarRetorno = document.getElementById("btnAdicionarRetorno");
  const modalProducao = document.getElementById("modalAdicionarProducao");
  const modalRetorno = document.getElementById("modalAdicionarRetorno");
  const closeButtons = document.querySelectorAll(".modal .close");

  const formProducao = document.getElementById("formAdicionarProducao");
  const formRetorno = document.getElementById("formAdicionarRetorno");

  const producaoList = document.getElementById("producaoList");
  const retornosList = document.getElementById("retornosList");

  const filtroTecnico = document.getElementById("filtroTecnico");
  const filtroData = document.getElementById("filtroData");
  const filtroTecnicoRetorno = document.getElementById("filtroTecnicoRetorno");
  const filtroDataRetorno = document.getElementById("filtroDataRetorno");

  const alertBox = document.getElementById("alertBox");

  let editProducaoId = null;
  let editRetornoId = null;

  // ============================
  // FUNÇÃO DE ALERTAS
  // ============================
  function mostrarAlerta(msg, tipo = "success") {
    if (!alertBox) return;
    alertBox.textContent = msg;
    alertBox.className = `alert ${tipo}`;
    alertBox.style.display = "block";
    setTimeout(() => (alertBox.style.display = "none"), 4000);
  }

  // ============================
  // MODAIS - ABRIR / FECHAR
  // ============================
  btnAdicionarProducao?.addEventListener("click", () => {
    modalProducao.style.display = "block";
    editProducaoId = null;
    formProducao.reset();

    // ✅ CORREÇÃO: Usa data local no formato YYYY-MM-DD (sem conversão para UTC)
    const hoje = new Date().toLocaleDateString('en-CA');
    document.getElementById("dataProducao").value = hoje;
    document.getElementById("dataProducao").readOnly = true;
  });

  btnAdicionarRetorno?.addEventListener("click", () => {
    modalRetorno.style.display = "block";
    editRetornoId = null;
    formRetorno.reset();
  });

  closeButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
      btn.closest(".modal").style.display = "none";
    });
  });

  window.addEventListener("click", (e) => {
    if (e.target === modalProducao) modalProducao.style.display = "none";
    if (e.target === modalRetorno) modalRetorno.style.display = "none";
  });

  // ============================
  // CARREGAR TÉCNICOS
  // ============================
  async function carregarTecnicos() {
    const { data, error } = await supabase.from("tecnicos").select("id, nome_completo");
    if (error) return console.error("Erro ao carregar técnicos:", error);

    [filtroTecnico, filtroTecnicoRetorno, document.getElementById("tecnicoProducao")].forEach((select) => {
      if (!select) return;
      select.innerHTML = '<option value="">Selecione</option>';
      data.forEach((tec) => {
        const opt = document.createElement("option");
        opt.value = tec.id;
        opt.textContent = tec.nome_completo;
        select.appendChild(opt);
      });
    });
  }

  // ============================
  // CARREGAR PRODUÇÃO
  // ============================
  async function carregarProducao() {
    const tecnicoId = filtroTecnico.value;
    const dataFiltro = filtroData.value;

    let query = supabase
      .from("producao")
      .select("id, data_producao, quantidade, descricao, tecnico_id, tecnicos!inner(nome_completo)")
      .order("data_producao", { ascending: false });

    if (tecnicoId) query = query.eq("tecnico_id", tecnicoId);
    if (dataFiltro) query = query.eq("data_producao", dataFiltro);

    const { data, error } = await query;
    if (error) return console.error("Erro ao carregar produção:", error);

    producaoList.innerHTML = "";
    data.forEach((item) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${item.tecnicos?.nome_completo || "—"}</td>
        <td>${item.data_producao}</td>
        <td>${item.quantidade}</td>
        <td>${item.descricao || ""}</td>
        <td>
          <button class="btn-editar" data-id="${item.id}">✏️</button>
          <button class="btn-excluir" data-id="${item.id}">🗑️</button>
        </td>
      `;
      producaoList.appendChild(tr);
    });

    producaoList.querySelectorAll(".btn-editar").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const { data } = await supabase.from("producao").select("*").eq("id", id).single();
        if (!data) return;
        editProducaoId = id;
        document.getElementById("tecnicoProducao").value = data.tecnico_id;
        document.getElementById("dataProducao").value = data.data_producao;
        document.getElementById("dataProducao").readOnly = false;
        document.getElementById("quantidadeProducao").value = data.quantidade;
        document.getElementById("descricaoProducao").value = data.descricao || "";
        modalProducao.style.display = "block";
      });
    });

    producaoList.querySelectorAll(".btn-excluir").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        if (confirm("Deseja realmente excluir esta produção?")) {
          const { error } = await supabase.from("producao").delete().eq("id", id);
          if (error) return mostrarAlerta("Erro ao excluir produção!", "error");
          mostrarAlerta("Produção excluída!");
          carregarProducao();
        }
      });
    });
  }

  // ============================
  // CARREGAR RETORNOS
  // ============================
  async function carregarRetornos() {
    const tecnicoId = filtroTecnicoRetorno.value;
    const dataFiltro = filtroDataRetorno.value;

    let query = supabase
      .from("retornos_instalacao")
      .select("id, data_instalacao, data_retorno, quantidade_ifi, motivo_retorno, producao!inner(tecnico_id, tecnicos!inner(nome_completo))")
      .order("data_retorno", { ascending: false });

    if (tecnicoId) query = query.eq("producao.tecnico_id", tecnicoId);
    if (dataFiltro) query = query.eq("data_retorno", dataFiltro);

    const { data, error } = await query;
    if (error) return console.error("Erro ao carregar retornos:", error);

    retornosList.innerHTML = "";
    data.forEach((item) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${item.producao?.tecnicos?.nome_completo || "—"}</td>
        <td>${item.data_instalacao}</td>
        <td>${item.data_retorno}</td>
        <td>${item.quantidade_ifi || ""}</td>
        <td>${item.motivo_retorno || ""}</td>
        <td>
          <button class="btn-editar" data-id="${item.id}">✏️</button>
          <button class="btn-excluir" data-id="${item.id}">🗑️</button>
        </td>
      `;
      retornosList.appendChild(tr);
    });

    retornosList.querySelectorAll(".btn-editar").forEach(async (btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const { data } = await supabase.from("retornos_instalacao").select("*").eq("id", id).single();
        if (!data) return;
        editRetornoId = id;
        document.getElementById("dataInstalacao").value = data.data_instalacao;
        document.getElementById("dataInstalacao").dispatchEvent(new Event('change'));
        document.getElementById("dataRetorno").value = data.data_retorno;
        document.getElementById("quantidade_ifi").value = data.quantidade_ifi;
        document.getElementById("motivoRetorno").value = data.motivo_retorno;
        modalRetorno.style.display = "block";
      });
    });

    retornosList.querySelectorAll(".btn-excluir").forEach((btn) => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        if (confirm("Deseja realmente excluir este retorno?")) {
          const { error } = await supabase.from("retornos_instalacao").delete().eq("id", id);
          if (error) return mostrarAlerta("Erro ao excluir retorno!", "error");
          mostrarAlerta("Retorno excluído!");
          carregarRetornos();
        }
      });
    });
  }

  // ============================
  // FILTRAR PRODUÇÕES POR DATA DA INSTALAÇÃO (NO MODAL DE RETORNO)
  // ============================
  document.getElementById("dataInstalacao")?.addEventListener("change", async (e) => {
    const dataSelecionada = e.target.value;
    const selectProducao = document.getElementById("producaoRetorno");
    
    if (!dataSelecionada) {
      selectProducao.innerHTML = '<option value="">Selecione uma data primeiro</option>';
      return;
    }

    const { data, error } = await supabase
      .from("producao")
      .select("id, data_producao, quantidade, tecnico_id, tecnicos!inner(nome_completo)")
      .eq("data_producao", dataSelecionada)
      .order("created_at", { ascending: false });

    if (error) {
      console.error("Erro ao carregar produções para a data selecionada:", error);
      selectProducao.innerHTML = '<option value="">Erro ao carregar</option>';
      return;
    }

    if (!data || data.length === 0) {
      selectProducao.innerHTML = '<option value="">Nenhuma produção nesta data</option>';
      return;
    }

    selectProducao.innerHTML = '<option value="">Selecione uma instalação</option>';
    data.forEach((item) => {
      const nomeTec = item.tecnicos?.nome_completo || "Técnico";
      const qtd = item.quantidade ?? "";
      const opt = document.createElement("option");
      opt.value = item.id;
      opt.textContent = `${nomeTec} — Qtd: ${qtd}`;
      selectProducao.appendChild(opt);
    });
  });

  // ============================
  // SALVAR PRODUÇÃO
  // ============================
  formProducao?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const tecnico_id = document.getElementById("tecnicoProducao").value;
    const data_producao = document.getElementById("dataProducao").value;
    const quantidade = document.getElementById("quantidadeProducao").value;
    const descricao = document.getElementById("descricaoProducao").value;

    let error;
    if (editProducaoId) {
      ({ error } = await supabase
        .from("producao")
        .update({ tecnico_id, data_producao, quantidade, descricao })
        .eq("id", editProducaoId));
    } else {
      ({ error } = await supabase
        .from("producao")
        .insert([{ tecnico_id, data_producao, quantidade, descricao }]));
    }

    if (error) {
      mostrarAlerta("Erro ao salvar produção!", "error");
      console.error(error);
    } else {
      mostrarAlerta(editProducaoId ? "Produção atualizada!" : "Produção adicionada!");
      modalProducao.style.display = "none";
      formProducao.reset();
      editProducaoId = null;
      carregarProducao();
    }
  });

  // ============================
  // SALVAR RETORNO
  // ============================
  formRetorno?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const producao_id = document.getElementById("producaoRetorno").value;
    const data_instalacao = document.getElementById("dataInstalacao").value;
    const data_retorno = document.getElementById("dataRetorno").value;
    const quantidade_ifi = document.getElementById("quantidade_ifi").value;
    const motivo_retorno = document.getElementById("motivoRetorno").value;

    if (!producao_id) {
      mostrarAlerta("Selecione uma instalação válida.", "error");
      return;
    }

    const diffDias = (new Date(data_retorno) - new Date(data_instalacao)) / (1000 * 60 * 60 * 24);
    if (diffDias > 15 || diffDias < 0) {
      mostrarAlerta("O retorno deve ocorrer entre 0 e 15 dias após a instalação.", "error");
      return;
    }

    let error;
    if (editRetornoId) {
      ({ error } = await supabase
        .from("retornos_instalacao")
        .update({ producao_id, data_instalacao, data_retorno, quantidade_ifi, motivo_retorno })
        .eq("id", editRetornoId));
    } else {
      ({ error } = await supabase
        .from("retornos_instalacao")
        .insert([{ producao_id, data_instalacao, data_retorno, quantidade_ifi, motivo_retorno }]));
    }

    if (error) {
      mostrarAlerta("Erro ao registrar retorno!", "error");
      console.error(error);
    } else {
      mostrarAlerta(editRetornoId ? "Retorno atualizado!" : "Retorno registrado!");
      modalRetorno.style.display = "none";
      formRetorno.reset();
      editRetornoId = null;
      carregarRetornos();
    }
  });

  // ============================
  // FILTROS
  // ============================
  [filtroTecnico, filtroData].forEach((el) => el?.addEventListener("change", carregarProducao));
  [filtroTecnicoRetorno, filtroDataRetorno].forEach((el) => el?.addEventListener("change", carregarRetornos));

  // ============================
  // INICIALIZAÇÃO
  // ============================
  await carregarTecnicos();
  await carregarProducao();
  await carregarRetornos();

  inserirBotoesImpressao();
});