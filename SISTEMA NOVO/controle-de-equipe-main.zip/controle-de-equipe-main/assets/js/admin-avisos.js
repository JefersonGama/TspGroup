// assets/js/admin-avisos.js
import { supabase } from '../../supabase/supabase-config.js';

document.addEventListener('DOMContentLoaded', function() {
    const avisosList = document.getElementById('avisosList');
    const modal = document.getElementById('modalNovoAviso');
    const btnNovoAviso = document.getElementById('btnNovoAviso');
    const spanClose = document.querySelector('.close');
    const formNovoAviso = document.getElementById('formNovoAviso');
    const dataAvisoInput = document.getElementById('dataAviso');

    // Função para carregar e exibir os avisos
    async function carregarAvisos() {
        const { data, error } = await supabase
            .from('avisos')
            .select(`
                id,
                titulo,
                descricao,
                data_aviso
            `)
            .order('data_aviso', { ascending: false });

        if (error) {
            console.error('Erro ao carregar avisos:', error);
            return;
        }

        avisosList.innerHTML = '';
        data.forEach(aviso => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${aviso.titulo}</td>
                <td>${new Date(aviso.data_aviso + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                <td>${aviso.descricao || 'N/A'}</td>
                <td class="action-buttons">
                    <button class="btn-delete" onclick="excluirAviso('${aviso.id}')">Excluir</button>
                </td>
            `;
            avisosList.appendChild(row);
        });
    }

    // Função para obter a data local atual no formato YYYY-MM-DD
    function getDataLocalAtual() {
        const hoje = new Date();
        const ano = hoje.getFullYear();
        const mes = String(hoje.getMonth() + 1).padStart(2, '0');
        const dia = String(hoje.getDate()).padStart(2, '0');
        return `${ano}-${mes}-${dia}`;
    }

    // Função para preencher automaticamente a data no modal
    function preencherDataAutomaticamente() {
        const dataHoje = getDataLocalAtual();
        dataAvisoInput.value = dataHoje;
    }

    // Eventos
    btnNovoAviso.addEventListener('click', () => {
        modal.style.display = 'block';
        preencherDataAutomaticamente();
    });

    spanClose.addEventListener('click', () => {
        modal.style.display = 'none';
    });

    window.addEventListener('click', (e) => {
        if (e.target === modal) {
            modal.style.display = 'none';
        }
    });

    formNovoAviso.addEventListener('submit', async (e) => {
        e.preventDefault();

        const formData = new FormData(formNovoAviso);
        const novoAviso = {
            titulo: formData.get('titulo'),
            descricao: formData.get('descricao'),
            // Corrigido para salvar a data no formato UTC correto
            data_aviso: new Date(formData.get('data_aviso') + 'T00:00:00').toISOString()
        };

        const { error } = await supabase
            .from('avisos')
            .insert([novoAviso]);

        if (error) {
            console.error('Erro ao adicionar aviso:', error);
            alert('Erro ao salvar aviso: ' + error.message);
        } else {
            alert('Aviso informativo adicionado com sucesso!');
            formNovoAviso.reset();
            preencherDataAutomaticamente();
            modal.style.display = 'none';
            carregarAvisos();
        }
    });

    // Função de exclusão
    window.excluirAviso = async (id) => {
        if (confirm('Tem certeza que deseja excluir este aviso informativo?')) {
            const { error } = await supabase
                .from('avisos')
                .delete()
                .eq('id', id);

            if (error) {
                console.error('Erro ao excluir aviso:', error);
                alert('Erro ao excluir aviso: ' + error.message);
            } else {
                alert('Aviso excluído com sucesso!');
                carregarAvisos();
            }
        }
    };

    // Inicializar
    carregarAvisos();
});
