// assets/js/tecnico-perfil.js
import { supabase } from '../../supabase/supabase-config.js';
import { getUsuarioLogado } from './auth.js';

document.addEventListener('DOMContentLoaded', async function() {
    // REMOVIDO: formEditarPerfil (não existe mais no HTML)
    // REMOVIDO: formAlterarSenha (não existe mais no HTML)

    const usuario = await getUsuarioLogado();
    if (!usuario) {
        window.location.href = '../index.html';
        return;
    }

    // Função para carregar e exibir os dados do perfil
    async function carregarPerfil() {
        // Obter dados do técnico diretamente usando o usuario_id
        const { data, error } = await supabase
            .from('tecnicos')
            .select('nome_completo, funcao')
            .eq('usuario_id', usuario.id) // Filtro pelo ID do usuário logado
            .single(); // Espera-se um único resultado

        if (error) {
            console.error('Erro ao carregar perfil do técnico:', error);
            // Pode-se adicionar uma mensagem de erro na tela, se desejado
            document.getElementById('perfilNome').textContent = 'Erro ao carregar';
            document.getElementById('perfilFuncao').textContent = 'Erro ao carregar';
            return;
        }

        if (!data) {
             console.error('Usuário logado não encontrado na tabela tecnicos.');
             // Pode-se redirecionar ou exibir uma mensagem de erro
             document.getElementById('perfilNome').textContent = 'Não encontrado';
             document.getElementById('perfilFuncao').textContent = 'Não encontrado';
             return;
        }

        // Atualizar nome no cabeçalho e nos campos de exibição
        const nomeCompleto = data.nome_completo;
        document.getElementById('nomeUsuario').textContent = nomeCompleto; // Alteração solicitada
        document.getElementById('perfilNome').textContent = nomeCompleto;
        document.getElementById('perfilEmail').textContent = usuario.email; // O email vem do usuário autenticado
        document.getElementById('perfilFuncao').textContent = data.funcao || 'N/A';
    }

    // REMOVIDO: Função getTecnicoId (não é mais necessária com a otimização)

    // Inicializar
    carregarPerfil();
});