// assets/js/notifications.js

/**
 * Solicita permissão e exibe uma notificação push do navegador
 * @param {string} titulo
 * @param {Object} options - Opções da notificação (body, icon, etc.)
 */
export function exibirNotificacaoNavegador(titulo, options = {}) {
    if (!("Notification" in window)) {
        console.log("Este navegador não suporta notificações de desktop.");
        return;
    }

    if (Notification.permission === "granted") {
        new Notification(titulo, options);
    } else if (Notification.permission !== "denied") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                new Notification(titulo, options);
            }
        });
    }
}

/**
 * Exibe uma notificação interna na tela (ex: toast ou banner)
 * @param {string} mensagem
 * @param {'info'|'success'|'warning'|'error'} tipo
 */
export function exibirNotificacaoInterna(mensagem, tipo = 'info') {
    // Exemplo simples com um "toast" fixo no canto superior direito
    const toast = document.createElement('div');
    toast.className = `notification-toast notification-${tipo}`;
    toast.textContent = mensagem;

    // Estilos básicos inline (melhor mover para CSS)
    toast.style.position = 'fixed';
    toast.style.top = '20px';
    toast.style.right = '20px';
    toast.style.padding = '10px 20px';
    toast.style.borderRadius = '4px';
    toast.style.color = 'white';
    toast.style.zIndex = '10000';
    toast.style.fontFamily = 'Arial, sans-serif';
    toast.style.fontSize = '14px';
    toast.style.opacity = '0';
    toast.style.transition = 'opacity 0.3s';
    toast.style.display = 'flex';
    toast.style.alignItems = 'center';

    // Cor de fundo baseada no tipo
    switch (tipo) {
        case 'success':
            toast.style.backgroundColor = '#2ecc71';
            break;
        case 'warning':
            toast.style.backgroundColor = '#f39c12';
            break;
        case 'error':
            toast.style.backgroundColor = '#e74c3c';
            break;
        case 'info':
        default:
            toast.style.backgroundColor = '#3498db';
            break;
    }

    document.body.appendChild(toast);

    // Animação de fade-in
    setTimeout(() => { toast.style.opacity = '1'; }, 10);

    // Remove após 5 segundos
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => {
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 300);
    }, 5000);
}

/**
 * Função para verificar novas notificações do backend (simulada)
 */
export function verificarNovasNotificacoes() {
    // Exemplo: verificar a cada 30 segundos
    // fetch('/api/notifications/unread') // Chamada real ao backend
    //    .then(response => response.json())
    //    .then(notificacoes => {
    //        notificacoes.forEach(n => exibirNotificacaoInterna(n.mensagem, n.tipo));
    //    });

    // Simulação
    console.log("Verificando novas notificações...");
    // exibirNotificacaoInterna("Novo aviso atribuído!", "info");
}