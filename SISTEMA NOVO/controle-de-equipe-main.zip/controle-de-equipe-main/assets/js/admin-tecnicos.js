// assets/js/admin-tecnicos.js
import { supabase } from '../../supabase/supabase-config.js';

const CREATE_USER_FUNCTION_URL = 'https://mnpheqtvhjyuoxfylvez.supabase.co/functions/v1/admin-create-user';
const DELETE_USER_FUNCTION_URL = 'https://mnpheqtvhjyuoxfylvez.supabase.co/functions/v1/admin-delete-user';

document.addEventListener('DOMContentLoaded', function() {

    // ==============================
    // ELEMENTOS DE TÉCNICOS
    // ==============================
    const tecnicosList = document.getElementById('tecnicosList');
    const modalTecnico = document.getElementById('modalNovoTecnico');
    const btnNovoTecnico = document.getElementById('btnNovoTecnico');
    const spanCloseTecnico = document.querySelector('.close');
    const formNovoTecnico = document.getElementById('formNovoTecnico');
    const selectEquipe = document.getElementById('equipeTecnico');

    // Novos elementos para e-mail e senha
    const emailPrefixInput = document.getElementById('emailTecnicoPrefix');
    const senhaInput = document.getElementById('senhaTecnico');
    const togglePasswordBtn = document.querySelector('.toggle-password');

    // ==============================
    // ELEMENTOS DE EQUIPES
    // ==============================
    const equipesList = document.getElementById('equipesList');
    const modalEquipe = document.getElementById('modalNovaEquipe');
    const btnNovaEquipe = document.getElementById('btnNovaEquipe');
    const spanCloseEquipe = document.querySelector('.closeEquipe');
    const formNovaEquipe = document.getElementById('formNovaEquipe');
    const modalEquipeTitulo = document.getElementById('modalEquipeTitulo');
    const equipeIdHidden = document.getElementById('equipeId');

    // ==============================
    // FUNÇÕES AUXILIARES
    // ==============================
    function getEmailCompleto() {
        const prefix = emailPrefixInput.value.trim();
        return prefix ? `${prefix}@tspgroup.online` : '';
    }

    // Toggle de visibilidade da senha
    togglePasswordBtn?.addEventListener('click', () => {
        const type = senhaInput.getAttribute('type') === 'password' ? 'text' : 'password';
        senhaInput.setAttribute('type', type);
        togglePasswordBtn.textContent = type === 'password' ? '👁️' : '🙈';
    });

    // ==============================
    // FUNÇÕES DE EQUIPES
    // ==============================
    async function carregarEquipesTabela() {
        const { data, error } = await supabase.from('equipe').select('*').order('nome', { ascending: true });
        if (error) return console.error('Erro ao carregar equipes:', error);

        equipesList.innerHTML = '';
        data.forEach(eq => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${eq.nome}</td>
                <td>${eq.supervisor || '—'}</td>
                <td>${eq.qtd_tecnicos || 0}</td>
                <td>
                    <button onclick="editarEquipe('${eq.id}')">Editar</button>
                    <button onclick="excluirEquipe('${eq.id}')">Excluir</button>
                </td>
            `;
            equipesList.appendChild(row);
        });

        carregarEquipesSelect();
    }

    async function carregarEquipesSelect() {
        const { data, error } = await supabase.from('equipe').select('id, nome').order('nome', { ascending: true });
        if (error) return console.error('Erro ao carregar equipes:', error);

        selectEquipe.innerHTML = '<option value="">Selecione uma equipe</option>';
        data.forEach(eq => {
            const option = document.createElement('option');
            option.value = eq.id;
            option.textContent = eq.nome;
            selectEquipe.appendChild(option);
        });
    }

    formNovaEquipe.addEventListener('submit', async (e) => {
        e.preventDefault();
        const nome = formNovaEquipe.nome.value.trim();
        const supervisor = formNovaEquipe.supervisor.value.trim();
        const equipeId = equipeIdHidden.value;

        if (!nome) return alert('Informe o nome da equipe.');

        try {
            if (equipeId) {
                await supabase.from('equipe').update({ nome, supervisor }).eq('id', equipeId);
                alert('Equipe atualizada com sucesso!');
            } else {
                await supabase.from('equipe').insert([{ nome, supervisor }]);
                alert('Equipe criada com sucesso!');
            }
        } catch (err) {
            console.error('Erro ao salvar equipe:', err);
            return alert('Erro ao salvar equipe.');
        }

        formNovaEquipe.reset();
        equipeIdHidden.value = '';
        modalEquipe.style.display = 'none';
        carregarEquipesTabela();
    });

    window.editarEquipe = async (id) => {
        const { data, error } = await supabase.from('equipe').select('*').eq('id', id).single();
        if (error) return alert('Erro ao carregar equipe.');
        modalEquipeTitulo.textContent = 'Editar Equipe';
        equipeIdHidden.value = data.id;
        formNovaEquipe.nome.value = data.nome;
        formNovaEquipe.supervisor.value = data.supervisor || '';
        modalEquipe.style.display = 'block';
    };

    window.excluirEquipe = async (id) => {
        if (!confirm('Tem certeza que deseja excluir esta equipe?')) return;
        try {
            await supabase.from('equipe').delete().eq('id', id);
            alert('Equipe excluída com sucesso!');
            carregarEquipesTabela();
        } catch (err) {
            console.error('Erro ao excluir equipe:', err);
            alert('Erro ao excluir equipe.');
        }
    };

    // ==============================
    // FUNÇÕES DE TÉCNICOS
    // ==============================
    async function carregarTecnicos() {
        const { data, error } = await supabase
            .from('tecnicos')
            .select(`id, nome_completo, funcao, equipe (nome), usuarios!tecnicos_usuario_id_fkey (email)`)
            .order('nome_completo');
        if (error) return console.error('Erro ao carregar técnicos:', error);

        tecnicosList.innerHTML = '';
        data.forEach(tecnico => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${tecnico.nome_completo}</td>
                <td>${tecnico.funcao || '—'}</td>
                <td>${tecnico.equipe?.nome || 'Sem equipe'}</td>
                <td>${tecnico.usuarios?.email || '—'}</td>
                <td>
                    <button onclick="editarTecnico('${tecnico.id}')">Editar</button>
                    <button onclick="excluirTecnico('${tecnico.id}')">Excluir</button>
                </td>
            `;
            tecnicosList.appendChild(row);
        });
    }

    // ==============================
    // CRIAR OU ATUALIZAR TÉCNICO
    // ==============================
    formNovoTecnico.addEventListener('submit', async (e) => {
        e.preventDefault();

        const nomeTecnico = formNovoTecnico.nome_completo.value.trim();
        const funcaoTecnico = formNovoTecnico.funcao.value.trim();
        const emailUsuario = getEmailCompleto();
        const senhaUsuario = senhaInput.value.trim();
        const equipeId = selectEquipe.value;
        const tecnicoId = formNovoTecnico.dataset.tecnicoId;

        if (!emailUsuario) return alert('Informe a parte do e-mail antes do @.');
        if (!senhaUsuario) return alert('Informe uma senha.');

        const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
        const token = sessionData?.session?.access_token;
        if (!token) return alert('Erro: usuário não autenticado.');

        try {
            if (tecnicoId) {
                // Atualiza técnico existente
                await supabase.from('tecnicos').update({
                    nome_completo: nomeTecnico,
                    funcao: funcaoTecnico,
                    equipe_id: equipeId || null
                }).eq('id', tecnicoId);

                alert('✅ Técnico atualizado com sucesso!');
                delete formNovoTecnico.dataset.tecnicoId;
            } else {
                // Cria novo técnico via Supabase Function
                const response = await fetch(CREATE_USER_FUNCTION_URL, {
                    method: 'POST',
                    headers: { 
                        'Authorization': `Bearer ${token}`, 
                        'Content-Type': 'application/json' 
                    },
                    body: JSON.stringify({
                        email: emailUsuario,
                        password: senhaUsuario,
                        nome_completo: nomeTecnico,
                        funcao: funcaoTecnico,
                        equipe_id: equipeId || null
                    }),
                });

                const result = await response.json();
                if (!response.ok) throw new Error(result.error || 'Erro ao criar técnico.');
                alert('✅ Técnico criado com sucesso!');
            }

            formNovoTecnico.reset();
            emailPrefixInput.value = '';
            senhaInput.value = '';
            modalTecnico.style.display = 'none';
            carregarTecnicos();
            carregarEquipesTabela();

        } catch (err) {
            console.error('🚨 Erro ao salvar técnico:', err);
            alert('Erro ao salvar técnico.');
        }
    });

    // ==============================
    // EDITAR TÉCNICO
    // ==============================
    window.editarTecnico = async (id) => {
        try {
            const { data, error } = await supabase.from('tecnicos').select('*').eq('id', id).single();
            if (error) return alert('Erro ao carregar técnico.');

            formNovoTecnico.nome_completo.value = data.nome_completo;
            formNovoTecnico.funcao.value = data.funcao || '';
            // Não preenchemos e-mail nem senha na edição
            emailPrefixInput.value = '';
            senhaInput.value = '';
            selectEquipe.value = data.equipe_id || '';
            formNovoTecnico.dataset.tecnicoId = data.id;

            modalTecnico.style.display = 'block';
        } catch (err) {
            console.error('Erro ao editar técnico:', err);
            alert('Erro ao editar técnico.');
        }
    };

    // ==============================
    // EXCLUIR TÉCNICO
    // ==============================
    async function atualizarQtdTecnicos(equipeId) {
        const { count } = await supabase.from('tecnicos').select('id', { count: 'exact', head: true }).eq('equipe_id', equipeId);
        await supabase.from('equipe').update({ qtd_tecnicos: count }).eq('id', equipeId);
    }

    window.excluirTecnico = async (id) => {
        if (!confirm('Excluir este técnico?')) return;

        const { data, error } = await supabase.from('tecnicos').select('usuario_id, equipe_id').eq('id', id).single();
        if (error) return alert('Erro ao buscar técnico.');

        const { data: sessionData } = await supabase.auth.getSession();
        const token = sessionData?.session?.access_token;

        try {
            await fetch(`${DELETE_USER_FUNCTION_URL}?id=${data.usuario_id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` },
            });
            await supabase.from('tecnicos').delete().eq('id', id);
            if (data.equipe_id) await atualizarQtdTecnicos(data.equipe_id);

            alert('Técnico excluído com sucesso!');
            carregarTecnicos();
            carregarEquipesTabela();
        } catch (err) {
            console.error('Erro ao excluir técnico:', err);
            alert('Erro ao excluir técnico.');
        }
    };

    // ==============================
    // EVENTOS DE MODAIS
    // ==============================
    btnNovoTecnico.addEventListener('click', () => {
        formNovoTecnico.reset();
        emailPrefixInput.value = '';
        senhaInput.value = '';
        delete formNovoTecnico.dataset.tecnicoId;
        modalTecnico.style.display = 'block';
        carregarEquipesSelect();
    });
    spanCloseTecnico.addEventListener('click', () => modalTecnico.style.display = 'none');
    btnNovaEquipe.addEventListener('click', () => {
        formNovaEquipe.reset();
        equipeIdHidden.value = '';
        modalEquipeTitulo.textContent = 'Nova Equipe';
        modalEquipe.style.display = 'block';
    });
    spanCloseEquipe.addEventListener('click', () => modalEquipe.style.display = 'none');

    window.addEventListener('click', (e) => {
        if (e.target === modalTecnico) modalTecnico.style.display = 'none';
        if (e.target === modalEquipe) modalEquipe.style.display = 'none';
    });

    // ==============================
    // INICIALIZAÇÃO
    // ==============================
    carregarTecnicos();
    carregarEquipesTabela();
});