const menuToggle = document.getElementById('menuToggle');
const sidebarMenu = document.getElementById('sidebarMenu');

menuToggle.addEventListener('click', () => {
    sidebarMenu.classList.toggle('active');
});
