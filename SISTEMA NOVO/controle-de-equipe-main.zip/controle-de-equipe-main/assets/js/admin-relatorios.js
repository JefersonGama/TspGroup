// assets/js/admin-relatorios.js
import { supabase } from '/supabase/supabase-config.js';

document.addEventListener('DOMContentLoaded', () => {

    // ---- Referências dos elementos ----
    const tipoRelatorioSelect = document.getElementById('tipoRelatorio');
    const filtroTecnicoDiv = document.getElementById('filtroTecnico');
    const tecnicoRelatorioSelect = document.getElementById('tecnicoRelatorio');
    const btnGerar = document.getElementById('btnGerarRelatorio');
    const resultadoRelatorioDiv = document.getElementById('resultadoRelatorio');
    const tituloResultadoRelatorio = document.getElementById('tituloResultadoRelatorio');
    const graficoRelatorioCanvas = document.getElementById('graficoRelatorio');
    const cabecalhoTabela = document.getElementById('cabecalhoTabela');
    const corpoTabelaRelatorio = document.getElementById('corpoTabelaRelatorio');
    const tabelaRelatorio = document.getElementById('tabelaRelatorio');

    let graficoAtual = null;
    const formatarDataBR = data => new Date(data).toLocaleDateString('pt-BR');

    // ---- Carregar Técnicos ----
    async function carregarTecnicos() {
        try {
            const { data, error } = await supabase
                .from('tecnicos')
                .select('id, nome_completo')
                .order('nome_completo', { ascending: true });

            if (error) throw error;

            tecnicoRelatorioSelect.innerHTML = '<option value="">Selecione um técnico</option>';
            data.forEach(tecnico => {
                const option = document.createElement('option');
                option.value = tecnico.id;
                option.textContent = tecnico.nome_completo;
                tecnicoRelatorioSelect.appendChild(option);
            });
        } catch (err) {
            console.error('Erro ao carregar técnicos:', err);
            alert('Erro ao carregar lista de técnicos.');
        }
    }

    // ---- Mostrar/Ocultar Filtro Técnico ----
    tipoRelatorioSelect.addEventListener('change', () => {
        filtroTecnicoDiv.style.display = tipoRelatorioSelect.value === 'tecnico' ? 'block' : 'none';
        limparResultado();
    });

    // ---- Evento de Geração ----
    btnGerar.addEventListener('click', gerarRelatorio);

    async function gerarRelatorio() {
        limparResultado();

        const tipo = tipoRelatorioSelect.value;
        const dataInicio = document.getElementById('dataInicio')?.value;
        const dataFim = document.getElementById('dataFim')?.value;

        if (!dataInicio || !dataFim) {
            alert('Por favor, selecione as datas de início e fim.');
            return;
        }

        if (tipo === 'tecnico' && !tecnicoRelatorioSelect.value) {
            alert('Por favor, selecione um técnico.');
            return;
        }

        btnGerar.disabled = true;
        btnGerar.textContent = 'Gerando...';

        try {
            const { dados, titulo, cabecalho, tipoGrafico } = await buscarDadosRelatorio(tipo, dataInicio, dataFim);

            resultadoRelatorioDiv.style.display = 'block';
            tituloResultadoRelatorio.textContent = titulo;

            renderTabela(dados, tipo, cabecalho);
            graficoAtual = renderGrafico(dados, tipo, titulo, tipoGrafico);
            renderBotaoImprimir(titulo, dados, tipo, cabecalho, dataInicio, dataFim);

        } catch (err) {
            console.error('Erro ao gerar relatório:', err);
            alert('Erro ao gerar relatório.');
        } finally {
            btnGerar.disabled = false;
            btnGerar.textContent = 'Gerar Relatório';
        }
    }

    // ---- Buscar Dados ----
    async function buscarDadosRelatorio(tipo, dataInicio, dataFim) {
        let dados = [];
        let titulo = '';
        let cabecalho = [];
        let tipoGrafico = 'bar';

        switch (tipo) {
            case 'equipe': {
                const { data, error } = await supabase.rpc('relatorio_producao_por_equipe', {
                    data_inicio: dataInicio,
                    data_fim: dataFim
                });
                if (error) throw error;
                dados = data ?? [];
                titulo = 'Produção por Equipe';
                cabecalho = ['Equipe', 'Total Produzido'];
                tipoGrafico = 'bar';
                break;
            }

            case 'tecnico': {
                const tecnicoId = tecnicoRelatorioSelect.value;
                const nomeTecnico = tecnicoRelatorioSelect.options[tecnicoRelatorioSelect.selectedIndex].text;
                const { data, error } = await supabase
                    .from('producao')
                    .select('data_producao, quantidade, descricao')
                    .eq('tecnico_id', tecnicoId)
                    .gte('data_producao', dataInicio)
                    .lte('data_producao', dataFim)
                    .order('data_producao', { ascending: true });
                if (error) throw error;
                dados = data ?? [];
                titulo = `Produção Diária do Técnico - ${nomeTecnico}`;
                cabecalho = ['Data', 'Quantidade', 'Descrição'];
                tipoGrafico = 'line';
                break;
            }

            case 'ordens': {
                // 🚨 Novo RPC para ordens diárias
                const { data, error } = await supabase.rpc('relatorio_ordens_diarias', {
                    data_inicio: dataInicio,
                    data_fim: dataFim
                });
                if (error) throw error;
                dados = data ?? [];
                titulo = 'Ordens Executadas por Dia';
                cabecalho = ['Data', 'Quantidade'];
                tipoGrafico = 'bar';
                break;
            }

            default:
                throw new Error('Tipo de relatório inválido.');
        }

        return { dados, titulo, cabecalho, tipoGrafico };
    }

    // ---- Render Tabela ----
    function renderTabela(dados, tipo, cabecalho) {
        cabecalhoTabela.innerHTML = '';
        cabecalho.forEach(col => {
            const th = document.createElement('th');
            th.textContent = col;
            cabecalhoTabela.appendChild(th);
        });

        corpoTabelaRelatorio.innerHTML = '';
        if (!dados || dados.length === 0) {
            const row = document.createElement('tr');
            cabecalho.forEach(() => {
                const td = document.createElement('td');
                td.textContent = '-';
                row.appendChild(td);
            });
            corpoTabelaRelatorio.appendChild(row);
            return;
        }

        dados.forEach(item => {
            const row = document.createElement('tr');
            if (tipo === 'equipe') {
                row.innerHTML = `<td>${item.nome_equipe || 'Desconhecida'}</td><td>${item.total_producao}</td>`;
            } else if (tipo === 'tecnico') {
                row.innerHTML = `<td>${formatarDataBR(item.data_producao)}</td><td>${item.quantidade}</td><td>${item.descricao || ''}</td>`;
            } else if (tipo === 'ordens') {
                row.innerHTML = `<td>${formatarDataBR(item.data)}</td><td>${item.total}</td>`;
            }
            corpoTabelaRelatorio.appendChild(row);
        });
    }

    // ---- Render Gráfico ----
    function renderGrafico(data, tipo, titulo, tipoGrafico) {
        if (typeof Chart === 'undefined') {
            alert('Erro: Chart.js não foi carregado.');
            return null;
        }

        const ctx = graficoRelatorioCanvas.getContext('2d');
        if (graficoAtual) graficoAtual.destroy();

        let chartData = { labels: [], datasets: [] };

        if (!data || data.length === 0) {
            chartData = {
                labels: ['Sem dados'],
                datasets: [{
                    label: 'Sem dados',
                    data: [0],
                    backgroundColor: ['rgba(200,200,200,0.5)']
                }]
            };
        } else if (tipo === 'equipe' || tipo === 'ordens') {
            chartData.labels = data.map(item => tipo === 'equipe' ? item.nome_equipe : formatarDataBR(item.data));
            chartData.datasets = [{
                label: tipo === 'equipe' ? 'Produção Total' : 'Quantidade',
                data: data.map(item => tipo === 'equipe' ? item.total_producao : item.total),
                backgroundColor: tipo === 'equipe'
                    ? 'rgba(100,196,223,0.7)'
                    : 'rgba(186,218,82,0.7)',
                borderColor: tipo === 'equipe'
                    ? 'rgba(100,196,223,1)'
                    : 'rgba(186,218,82,1)',
                borderWidth: 1
            }];
        } else if (tipo === 'tecnico') {
            chartData.labels = data.map(item => formatarDataBR(item.data_producao));
            chartData.datasets = [{
                label: 'Quantidade Produzida',
                data: data.map(item => item.quantidade),
                fill: false,
                borderColor: 'rgba(100,196,223,1)',
                backgroundColor: 'rgba(100,196,223,0.2)',
                tension: 0.1
            }];
        }

        return new Chart(ctx, {
            type: tipoGrafico,
            data: chartData,
            options: {
                responsive: true,
                plugins: {
                    title: { display: true, text: titulo, font: { size: 16 } },
                    legend: { display: tipoGrafico !== 'doughnut' }
                },
                scales: tipoGrafico !== 'doughnut' ? { y: { beginAtZero: true } } : {}
            }
        });
    }

    // ---- Botão de Imprimir ----
    function renderBotaoImprimir(titulo, dados, tipo, cabecalho, dataInicio, dataFim) {
        const botaoExistente = document.getElementById('btnImprimirRelatorio');
        if (botaoExistente) botaoExistente.remove();

        let containerBotao = document.getElementById('containerBotaoImprimir');
        if (!containerBotao) {
            containerBotao = document.createElement('div');
            containerBotao.id = 'containerBotaoImprimir';
            containerBotao.style.textAlign = 'right';
            containerBotao.style.marginTop = '15px';
            tabelaRelatorio.parentNode.appendChild(containerBotao);
        } else {
            containerBotao.innerHTML = '';
        }

        const botao = document.createElement('button');
        botao.id = 'btnImprimirRelatorio';
        botao.textContent = 'Imprimir Relatório';
        botao.className = 'btn-imprimir';
        botao.style.cssText = `
            padding: 8px 15px; cursor: pointer; background-color: #4CAF50;
            color: white; border: none; border-radius: 4px;
        `;

        botao.addEventListener('click', () => {
            const conteudo = `
                <div style="text-align:center;">
                    <img src="/assets/images/logo.png" alt="Logo" style="width:150px; height:auto; display:block; margin: 0 auto 20px auto;">
                </div>
                <h2 style="text-align:center;">${titulo}</h2>
                <p style="text-align:center;">Período: ${dataInicio} a ${dataFim}</p>
                <table border="1" style="border-collapse: collapse; width: 100%;">
                    <thead>
                        <tr>${cabecalho.map(col => `<th>${col}</th>`).join('')}</tr>
                    </thead>
                    <tbody>
                        ${dados.length === 0
                            ? `<tr>${cabecalho.map(() => `<td>-</td>`).join('')}</tr>`
                            : dados.map(item => {
                                if (tipo === 'equipe') return `<tr><td>${item.nome_equipe}</td><td>${item.total_producao}</td></tr>`;
                                if (tipo === 'tecnico') return `<tr><td>${formatarDataBR(item.data_producao)}</td><td>${item.quantidade}</td><td>${item.descricao || ''}</td></tr>`;
                                if (tipo === 'ordens') return `<tr><td>${formatarDataBR(item.data)}</td><td>${item.total}</td></tr>`;
                                return '';
                            }).join('')}
                    </tbody>
                </table>
            `;

            const novaJanela = window.open('', '_blank');
            if (!novaJanela) return alert('Permita pop-ups para visualizar o relatório.');

            novaJanela.document.write(`
                <html>
                    <head>
                        <title>Relatório - ${titulo}</title>
                        <style>
                            body { font-family: Arial, sans-serif; padding: 20px; }
                            table { width: 100%; margin-top: 20px; }
                            th, td { padding: 8px; border: 1px solid #ccc; }
                            th { background-color: #f2f2f2; }
                        </style>
                    </head>
                    <body>
                        ${conteudo}
                        <script>window.onload = () => { window.print(); window.close(); }</script>
                    </body>
                </html>
            `);
            novaJanela.document.close();
        });
        containerBotao.appendChild(botao);
    }

    function limparResultado() {
        resultadoRelatorioDiv.style.display = 'none';
        if (graficoAtual) graficoAtual.destroy();
        graficoAtual = null;

        document.getElementById('btnImprimirRelatorio')?.remove();
        const container = document.getElementById('containerBotaoImprimir');
        if (container) container.innerHTML = '';
    }

    // ---- Inicialização de Datas ----
    const hoje = new Date().toISOString().split('T')[0];
    const inicioPadrao = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0];
    document.getElementById('dataInicio')?.setAttribute('value', inicioPadrao);
    document.getElementById('dataFim')?.setAttribute('value', hoje);

    // ---- Carregar Técnicos ----
    carregarTecnicos();
});
