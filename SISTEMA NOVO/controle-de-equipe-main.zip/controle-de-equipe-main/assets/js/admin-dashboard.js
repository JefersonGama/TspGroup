import { supabase } from '../../supabase/supabase-config.js';
import { getUsuarioLogado } from './auth.js';

document.addEventListener('DOMContentLoaded', async function() {
    console.log("Admin Dashboard: Iniciando verificação de sessão...");

    const usuario = await getUsuarioLogado();
    console.log("Admin Dashboard: Resultado de getUsuarioLogado:", usuario);

    if (!usuario || usuario.tipo_usuario !== 'admin') {
        console.log("Admin Dashboard: Nenhum usuário válido encontrado, redirecionando para login...");
        window.location.href = '../index.html';
        return;
    }

    // ==============================
    // FUNÇÃO PRINCIPAL DO DASHBOARD
    // ==============================
    async function carregarDadosDashboard() {
        console.log("Admin Dashboard: Carregando dados...");

        // 🔹 Contar técnicos
        const { count: tecnicosCount, error: errorTecnicos } = await supabase
            .from('tecnicos')
            .select('*', { count: 'exact', head: true });

        if (errorTecnicos) {
            console.error('Admin Dashboard: Erro ao contar técnicos:', errorTecnicos);
        } else {
            document.getElementById('tecnicos-count').textContent = tecnicosCount ?? 0;
        }

        // 🔹 Produção do dia
        const hoje = new Date();
        const hojeStr = `${hoje.getFullYear()}-${String(hoje.getMonth()+1).padStart(2,'0')}-${String(hoje.getDate()).padStart(2,'0')}`;
        const { data: producaoHoje, error: errorProducao } = await supabase
            .from('producao')
            .select('quantidade')
            .eq('data_producao', hojeStr);

        if (errorProducao) {
            console.error('Admin Dashboard: Erro ao buscar produção de hoje:', errorProducao);
        } else if (!producaoHoje || producaoHoje.length === 0) {
            document.getElementById('producao-hoje').textContent = 0;
        } else {
            const totalProducao = producaoHoje.reduce((acc, curr) => acc + (curr.quantidade || 0), 0);
            document.getElementById('producao-hoje').textContent = totalProducao;
        }

        // 🔹 Avisos recentes
        const avisosContainer = document.getElementById('avisos-recentes');
        const { data: avisosRecentes, error: errorAvisosRecentes } = await supabase
            .from('avisos')
            .select('id, titulo, data_aviso')
            .order('data_aviso', { ascending: false })
            .limit(5);

        if (errorAvisosRecentes) {
            console.error('Admin Dashboard: Erro ao carregar avisos recentes:', errorAvisosRecentes);
        } else if (!avisosRecentes || avisosRecentes.length === 0) {
            avisosContainer.innerHTML = '<p>Nenhum aviso recente encontrado.</p>';
        } else {
            avisosContainer.innerHTML = '';
            avisosRecentes.forEach(aviso => {
                const div = document.createElement('div');
                div.className = 'aviso-item';
                // 🔹 Corrigido para timezone local
                div.innerHTML = `<strong>${aviso.titulo}</strong> - ${new Date(aviso.data_aviso + 'T00:00:00').toLocaleDateString('pt-BR')}`;
                avisosContainer.appendChild(div);
            });
        }

        // 🔹 Carregar dados das equipes
        await carregarDadosEquipes();
    }

    // ==============================
    // FUNÇÃO PARA CARREGAR DADOS DAS EQUIPES
    // ==============================
    async function carregarDadosEquipes() {
        const container = document.getElementById('equipes-container');
        if (!container) {
            console.error("Container 'equipes-container' não encontrado no HTML.");
            return;
        }

        const hoje = new Date();
        const primeiroDiaMes = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
        const ultimoDiaMes = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
        const dataInicioMes = `${primeiroDiaMes.getFullYear()}-${String(primeiroDiaMes.getMonth()+1).padStart(2,'0')}-${String(primeiroDiaMes.getDate()).padStart(2,'0')}`;
        const dataFimMes = `${ultimoDiaMes.getFullYear()}-${String(ultimoDiaMes.getMonth()+1).padStart(2,'0')}-${String(ultimoDiaMes.getDate()).padStart(2,'0')}`;

        const { data: producao, error: errorEquipes } = await supabase
            .from('producao')
            .select(`
                quantidade,
                tecnico_id,
                tecnicos!inner (
                    id,
                    equipe_id,
                    equipe (
                        id,
                        nome
                    )
                )
            `)
            .gte('data_producao', dataInicioMes)
            .lte('data_producao', dataFimMes);

        if (errorEquipes) {
            console.error('Admin Dashboard: Erro ao carregar equipes com instalações:', errorEquipes);
            return;
        }

        container.innerHTML = '';

        if (!producao || producao.length === 0) {
            container.innerHTML = '<p>Nenhuma equipe realizou instalações este mês.</p>';
            return;
        }

        const equipesMap = new Map();
        producao.forEach(item => {
            const equipe = item.tecnicos?.equipe;
            if (!equipe) return;

            if (!equipesMap.has(equipe.id)) {
                equipesMap.set(equipe.id, {
                    nome: equipe.nome,
                    totalInstalacoes: 0,
                    totalIfi: 0
                });
            }

            const equipeData = equipesMap.get(equipe.id);
            equipeData.totalInstalacoes += item.quantidade || 0;
        });

        const { data: ifis, error: errorIfi } = await supabase
            .from('retornos_instalacao')
            .select(`
                quantidade_ifi,
                producao!inner (
                    id,
                    tecnico_id,
                    tecnicos!inner (
                        equipe_id
                    )
                )
            `)
            .gte('data_retorno', dataInicioMes)
            .lte('data_retorno', dataFimMes);

        if (errorIfi) {
            console.error('Admin Dashboard: Erro ao carregar dados de IFI:', errorIfi);
        } else if (ifis && ifis.length > 0) {
            for (const item of ifis) {
                const equipeId = item.producao?.tecnicos?.equipe_id;
                if (!equipeId || !equipesMap.has(equipeId)) continue;

                const equipeData = equipesMap.get(equipeId);
                equipeData.totalIfi += item.quantidade_ifi || 0;
            }
        }

        for (const [equipeId, equipe] of equipesMap.entries()) {
            const porcentagemIfi = equipe.totalInstalacoes > 0
                ? (equipe.totalIfi / equipe.totalInstalacoes) * 100
                : 0;

            let corIfi = 'inherit';
            if (porcentagemIfi <= 1) corIfi = 'green';
            else if (porcentagemIfi <= 3) corIfi = 'gold';
            else corIfi = 'red';

            const card = document.createElement('div');
            card.className = 'card equipe-card';
            card.innerHTML = `
                <h3>${equipe.nome}</h3>
                <p><strong>Instalações (Mês):</strong> ${equipe.totalInstalacoes}</p>
                <p style="color: ${corIfi};">
                    <strong>IFI:</strong> ${equipe.totalIfi} (${porcentagemIfi.toFixed(2)}%)
                </p>
            `;
            container.appendChild(card);
        }
    }

    // Executar dashboard
    carregarDadosDashboard();
});
