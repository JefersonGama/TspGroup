// assets/js/auth.js
import { supabase } from '../../supabase/supabase-config.js';

// Listener de mudança de autenticação
const handleAuthStateChange = async (event, session) => {
    console.log("Estado de autenticação mudou:", event, session);
};

// Inicia o listener
supabase.auth.onAuthStateChange(handleAuthStateChange);

// LOGIN
document.getElementById('loginForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const email = document.getElementById('email').value;
    const senha = document.getElementById('senha').value;

    const { data, error } = await supabase.auth.signInWithPassword({
        email: email,
        password: senha,
    });

    if (error) {
        console.error('Erro de autenticação:', error);
        alert('Erro ao fazer login: ' + error.message);
        return;
    }

    console.log("Login bem-sucedido.");
    console.log("Session Data:", data.session);

    const tipoUsuario = data.session?.user?.user_metadata?.tipo_usuario;
    console.log("Tipo de usuário do meta:", tipoUsuario);

    if (tipoUsuario === 'admin') {
        window.location.href = 'admin/dashboard.html';
    } else if (tipoUsuario === 'tecnico') {
        window.location.href = 'tecnico/dashboard.html';
    } else {
        console.error('Tipo de usuário inválido ou não encontrado:', tipoUsuario);
        alert('Tipo de usuário inválido ou não encontrado. Contate o administrador.');
        await supabase.auth.signOut();
    }
});

// FUNÇÃO AUXILIAR
export async function getUsuarioLogado() {
    console.log("getUsuarioLogado: Tentando obter sessão...");

    // CORREÇÃO AQUI ⬇️
    const { data, error } = await supabase.auth.getSession();
    const session = data?.session;

    console.log("getUsuarioLogado: Resposta do getSession:", session, error);

    if (error || !session) {
        console.error('getUsuarioLogado: Erro ao obter sessão ou sessão não existe:', error);
        return null;
    }

    const userId = session.user.id;
    const userEmail = session.user.email;
    const tipoUsuario = session.user.user_metadata?.tipo_usuario;

    console.log("getUsuarioLogado: Sessão válida encontrada, ID:", userId, "Tipo:", tipoUsuario);

    return {
        id: userId,
        email: userEmail,
        tipo_usuario: tipoUsuario
    };
}

// LOGOUT
document.getElementById('logoutBtn')?.addEventListener('click', async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
        console.error('Erro ao sair:', error.message);
        alert('Erro ao sair. Tente novamente.');
    } else {
        window.location.href = '../index.html';
    }
});
