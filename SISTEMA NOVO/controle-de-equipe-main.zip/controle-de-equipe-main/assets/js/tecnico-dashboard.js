import { supabase } from '../../supabase/supabase-config.js';
import { getUsuarioLogado } from './auth.js';

document.addEventListener('DOMContentLoaded', async function () {
    const usuario = await getUsuarioLogado();
    if (!usuario) {
        window.location.href = '../index.html';
        return;
    }

    const tecnicoId = await getTecnicoId(usuario.id);
    if (!tecnicoId) {
        console.error("Usuário não é um técnico cadastrado.");
        return;
    }

    // Obter o nome completo do técnico da tabela 'tecnicos'
    const { data: tecnicoData, error: tecnicoError } = await supabase
        .from('tecnicos')
        .select('nome_completo')
        .eq('usuario_id', usuario.id)
        .single();

    if (tecnicoError || !tecnicoData || !tecnicoData.nome_completo) {
        console.error("Erro ao obter nome completo do técnico:", tecnicoError?.message || "Nome completo não encontrado.");
        // Fallback para o nome de exibição do usuário
        const nomeExibicao = usuario.user_metadata?.full_name || usuario.email.split('@')[0];
        document.getElementById('nomeUsuario').textContent = nomeExibicao;
    } else {
        document.getElementById('nomeUsuario').textContent = tecnicoData.nome_completo;
    }

    await carregarDadosDashboard(tecnicoId);
});

async function getTecnicoId(usuarioId) {
    const { data, error } = await supabase
        .from('tecnicos')
        .select('id')
        .eq('usuario_id', usuarioId)
        .single();
    return error ? null : data.id;
}

async function carregarDadosDashboard(tecnicoId) {
    const hoje = new Date();
    const dataHoje = hoje.toISOString().split('T')[0];
    const ano = hoje.getFullYear();
    const mes = String(hoje.getMonth() + 1).padStart(2, '0');
    const ultimoDiaMes = new Date(ano, hoje.getMonth() + 1, 0).getDate();
    const inicioMes = `${ano}-${mes}-01`;
    const fimMes = `${ano}-${mes}-${ultimoDiaMes}`;

    // === 1. Produção Diária ===
    const { data: producaoDiaria } = await supabase
        .from('producao')
        .select('quantidade')
        .eq('tecnico_id', tecnicoId)
        .eq('data_producao', dataHoje);

    const totalDiario = producaoDiaria?.reduce((acc, p) => acc + (p.quantidade || 0), 0) || 0;
    document.getElementById('producao-diaria-valor').textContent = totalDiario;

    // === 2. Produção Mensal (instalações) ===
    const { data: producaoMensal } = await supabase
        .from('producao')
        .select('quantidade')
        .eq('tecnico_id', tecnicoId)
        .gte('data_producao', inicioMes)
        .lte('data_producao', fimMes);

    const totalInstalacoes = producaoMensal?.reduce((acc, p) => acc + (p.quantidade || 0), 0) || 0;
    document.getElementById('producao-mensal-valor').textContent = totalInstalacoes;

    // === 3. Retornos Mensais (via tabela retornos_instalacao) ===
    let totalRetornos = 0;
    try {
        // Buscar retornos cuja instalação ocorreu neste mês
        const { data: retornos } = await supabase
            .from('retornos_instalacao')
            .select('quantidade_ifi, producao_id')
            .gte('data_instalacao', inicioMes)
            .lte('data_instalacao', fimMes);

        if (retornos && retornos.length > 0) {
            const idsProducao = retornos
                .map(r => r.producao_id)
                .filter(id => id !== null);

            if (idsProducao.length > 0) {
                // Verificar quais produções pertencem ao técnico atual
                const { data: producoesDoTecnico } = await supabase
                    .from('producao')
                    .select('id')
                    .in('id', idsProducao)
                    .eq('tecnico_id', tecnicoId);

                const idsValidos = new Set(producoesDoTecnico?.map(p => p.id) || []);
                totalRetornos = retornos
                    .filter(r => r.producao_id && idsValidos.has(r.producao_id))
                    .reduce((acc, r) => acc + (r.quantidade_ifi || 1), 0);
            }
        }
    } catch (err) {
        console.error('Erro ao buscar retornos:', err);
    }

    // === 4. Calcular IFI e aplicar estilo condicional ===
    let ifiPercentual = 0;
    if (totalInstalacoes > 0) {
        ifiPercentual = (totalRetornos / totalInstalacoes) * 100;
    }

    const ifiTexto = `${ifiPercentual.toFixed(1)}%`;
    const ifiElement = document.getElementById('ifi-mensal-valor');
    ifiElement.textContent = `IFI: ${ifiTexto}`;

    // Limpar classes anteriores
    ifiElement.classList.remove('ifi-baixo', 'ifi-alto');

    // Aplicar cor com base no limite de 3%
    if (ifiPercentual > 3) {
        ifiElement.classList.add('ifi-alto'); // vermelho (deve ser definido no CSS)
    } else {
        ifiElement.classList.add('ifi-baixo'); // verde (ou cor padrão)
    }

    // === 5. Últimos Avisos da Empresa (avisos gerais) ===
    const { data: ultimosAvisos } = await supabase
        .from('avisos')
        .select('titulo, descricao, data_aviso')
        .order('data_aviso', { ascending: false })
        .limit(5);

    const container = document.getElementById('ultimos-avisos');
    if (!ultimosAvisos || ultimosAvisos.length === 0) {
        container.innerHTML = '<p>Nenhum aviso publicado.</p>';
    } else {
        container.innerHTML = ultimosAvisos.map(aviso => {
            const dataFormatada = new Date(aviso.data_aviso).toLocaleDateString('pt-BR');
            return `
                <div class="aviso-item">
                    <strong>${aviso.titulo}</strong><br>
                    <small>${dataFormatada}</small>
                    ${aviso.descricao ? `<p class="aviso-descricao">${aviso.descricao}</p>` : ''}
                </div>
            `;
        }).join('');
    }
}