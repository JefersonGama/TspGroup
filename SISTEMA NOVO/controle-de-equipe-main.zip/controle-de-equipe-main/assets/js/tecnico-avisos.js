// assets/js/tecnico-avisos.js
import { supabase } from '../../supabase/supabase-config.js';
import { getUsuarioLogado } from './auth.js';

document.addEventListener('DOMContentLoaded', async function() {
    const meusAvisosList = document.getElementById('meusAvisosList');
    const statusFilter = document.getElementById('statusFilter');
    const searchInput = document.getElementById('searchInput');

    const usuario = await getUsuarioLogado();
    if (!usuario) {
        window.location.href = '../index.html';
        return;
    }

    // Carregar nome do usuário
    document.getElementById('nomeUsuario').textContent = usuario.user_metadata?.full_name || usuario.email.split('@')[0];

    let avisosOriginais = []; // Para armazenar os dados originais e filtrar

    // Função para carregar e exibir os avisos do técnico
    async function carregarMeusAvisos() {
        const tecnicoId = await getTecnicoId(usuario.id);

        if (!tecnicoId) {
            console.error("Usuário logado não é um técnico cadastrado.");
            return;
        }

        const { data, error } = await supabase
            .from('avisos')
            .select(`
                id,
                titulo,
                descricao,
                data_aviso,
                status
            `)
            .eq('tecnico_responsavel_id', tecnicoId)
            .order('data_aviso', { ascending: false });

        if (error) {
            console.error('Erro ao carregar meus avisos:', error);
            return;
        }

        avisosOriginais = data;
        renderizarAvisos(avisosOriginais);
    }

    // Função para renderizar os avisos na tabela
    function renderizarAvisos(avisos) {
        meusAvisosList.innerHTML = '';
        avisos.forEach(aviso => {
            const row = document.createElement('tr');
            row.innerHTML = `
                <td>${aviso.titulo}</td>
                <td>${new Date(aviso.data_aviso).toLocaleDateString('pt-BR')}</td>
                <td><span class="status-${aviso.status}">${aviso.status}</span></td>
                <td class="action-buttons">
                    <button class="btn-view" onclick="verDetalhesAviso('${aviso.id}')">Ver</button>
                </td>
            `;
            meusAvisosList.appendChild(row);
        });
    }

    // Função para filtrar os avisos com base no status e pesquisa
    function filtrarAvisos() {
        const filtroStatus = statusFilter.value;
        const termoPesquisa = searchInput.value.toLowerCase();

        let avisosFiltrados = avisosOriginais;

        if (filtroStatus) {
            avisosFiltrados = avisosFiltrados.filter(aviso => aviso.status === filtroStatus);
        }

        if (termoPesquisa) {
            avisosFiltrados = avisosFiltrados.filter(aviso =>
                aviso.titulo.toLowerCase().includes(termoPesquisa) ||
                aviso.descricao.toLowerCase().includes(termoPesquisa)
            );
        }

        renderizarAvisos(avisosFiltrados);
    }

    // Função auxiliar para obter o ID do técnico a partir do ID do usuário
    async function getTecnicoId(usuarioId) {
        const { data, error } = await supabase
            .from('tecnicos')
            .select('id')
            .eq('usuario_id', usuarioId)
            .single();

        if (error) {
            console.error('Erro ao buscar ID do técnico:', error);
            return null;
        }
        return data.id;
    }

    // Eventos de filtro
    statusFilter.addEventListener('change', filtrarAvisos);
    searchInput.addEventListener('input', filtrarAvisos);

    // Função de ação (ver detalhes)
    window.verDetalhesAviso = (id) => {
        alert('Ver detalhes do aviso com ID: ' + id + ' (Funcionalidade em desenvolvimento)');
        // Poderia abrir um modal ou redirecionar para uma página de detalhes
    };

    // Inicializar
    carregarMeusAvisos();
});